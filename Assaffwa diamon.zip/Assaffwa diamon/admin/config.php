<?php

$server = 'localhost';
$user = 'root';
$pass = '';
$db = 'assaffwa diamon';

$conn = mysqli_connect($server,$user,$pass) or die("error");

$selectab=mysqli_select_db($conn,$db) or die("error");




?>