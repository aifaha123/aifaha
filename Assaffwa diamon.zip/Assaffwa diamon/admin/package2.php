<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="stylesheet" href="style_list.css">
</head>
<body>
<?php
include_once('connection.php');
$sql="select pack_id, pack_type, pack_budget, pack_flight, pack_hotel, a_id from package";
$result= $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table><tr><th>ID</th><th>Package</th><th>Total</th><th>Flight</th><th>Hotel</th><th>Action</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["pack_id"]. "</td><td>" .$row['pack_type']. " </td><td> " . $row['pack_budget']. " </td><td> " . $row['pack_flight']. " </td><td> " . $row['pack_hotel']. " </td><td> " .$row['a_id']. " </td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}

$conn->close();
?>


</body>
</html>