<?php
include 'config.php';
if (isset($_POST["a_btn"])){
  $a_email =$_POST["a_email"];
  $a_pass =$_POST["a_pass"];
   if ( empty($a_email)|| empty($a_pass)){
	   echo"Please Complet All Data";
   }else{ 
   $selectfdb = mysqli_query($conn,"SELECT * FROM admin WHERE a_email = '$a_email' AND a_pass = '$a_pass' ");
   $row = mysqli_fetch_array($selectfdb);
    if($row["a_email"] == $a_email && $row["a_pass"] == $a_pass){
		echo "Welcome ".$row["a_firstname"]." in Your Account";
	}else{
		 echo"Email or Password Incorrect";
	} 
  }
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="style_ad.css">
    <link href="https://fonts.googleapis.com/css?family=Permanent+Marker" rel="stylesheet">
  </head>
  <body>
    <div class="login-form">
      <form class="" action="admin_page.php" method="post">
        <h1>Login</h1>
		
        <input type="email" name="a_email" placeholder="Email" class="txtb">
        <input type="password" name="a_pass" placeholder="Password" class="txtb">
        <input type="submit" name="a_btn"value="Login" class="login-btn">
        
      </form>
    </div>
  </body>
</html>
