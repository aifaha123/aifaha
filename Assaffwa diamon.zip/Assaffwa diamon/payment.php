<?php
include 'config.php';
if (isset($_POST["pay_btn"])){
  $pay_detail =$_POST["pay_detail"];
  $pay_total =$_POST["pay_total"];
  
  if (empty($pay_detail) ||  empty($pay_total)){
  }else{
	  $insert = mysqli_query($conn,"INSERT INTO `payment` (`pay_detail`, `pay_total`, `book_id`, `a_id`) VALUES ('$pay_detail', '$pay_total');");
	  echo "succes";
  }
}
 
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="style_pay.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/punycode/1.4.1/punycode.min.js"></script>
<script src="https://cdn.jotfor.ms/static/prototype.forms.js" type="text/javascript"></script>
<script src="https://cdn.jotfor.ms/static/jotform.forms.js?3.3.19032" type="text/javascript"></script>
<script src="https://cdn.jotfor.ms/js/payments/paypalcomplete.js?v=3.3.19032" type="text/javascript"></script>
<script src="https://cdn.jotfor.ms/js/payments/paymentUtils.js?v=3.3.19032" type="text/javascript"></script>
<script src="https://cdn.jotfor.ms/js/libraries/promise-polyfill.js"></script>
<script src="https://cdn.jotfor.ms/js/payments/payment_form_embedded.js?v=3.3.19032" type="text/javascript"></script>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
</head>

<body>
<div class="topnav">
  <a class="active" href="user_page.php">Home</a>
  <a href="package.html">PACKAGE</a>
  <a href="register.php">REGISTER</a>
  <a href="payment.php">PAYMENT</a>
  <div class=" More ">
    <button class="dropbtn"> More 
    </button>
    <div class="More-content">
      <a href="contact.html">Contact</a>
	  <a href="#">Budget</a> 
      <a href="MUTAWWIF TEAM.html">Mutawwif</a>
	  
	</div>
  </div> 
  </div>
  
  <h2>ASSAFFWA DAIMON TRAVEL</h2>
  
<p>Terima kasih kerana menghubungi kami berkenaan pakej "PAKAGE".</p>
<p>Kami akan berhubung dengan anda melalui Emel dalam masa 2-3 hari bekerja.</p>
<p>Sementara menunggu maklum balas dari kami, kenalilah kami lebih dekat dengan melayari dan melanggani update kami di.</p>

<div class="row">
  <div class="col-75">
    <div class="container">
      <form action="payment.php" method="post">
      
		<div class="row">
          <div class="col-50">
            <h3>Billing Package</h3>
             <label for="name">Your Package </label>
      <select class="form-control" id="pay_detail" name="pay_detail">
        <option>BRONZE</option>
        <option>PLATINUIM</option>
        <option>GOLD</option>
      </select>
            <label for="room">Choose you Type of room(2, 3, 4)</label>
    <select class="form-control" id="pay_total" name="pay_total">
        <option>Room 2 - RM 7200</option>
        <option>Room 3 - RM 6800</option>
        <option>Room 4 - RM 6500</option>
      </select>
          <div class="col-50">
            <h3>Payment</h3>
            <label for="fname">Accepted Cards</label>
            <div class="icon-container">
              <i class="fa fa-cc-visa" style="color:navy;"></i>
              <i class="fa fa-cc-amex" style="color:blue;"></i>
              <i class="fa fa-cc-mastercard" style="color:red;"></i>
              <i class="fa fa-cc-discover" style="color:orange;"></i>
            </div>
            <label for="cname">Name on Card</label>
            <input type="text" id="cname" name="cardname" placeholder="">
            <label for="ccnum">Credit card number</label>
            <input type="text" id="ccnum" name="cardnumber" placeholder="">
            <label for="expmonth">Exp Month</label>
            <input type="text" id="expmonth" name="expmonth" placeholder="">
            <div class="row">
              <div class="col-50">
                <label for="expyear">Exp Year</label>
                <input type="text" id="expyear" name="expyear" placeholder="">
              </div>
              <div class="col-50">
                <label for="cvv">CVV</label>
                <input type="text" id="cvv" name="cvv" placeholder="">
              </div>
            </div>
          </div>
          
        </div>
      
		<input name="pay_btn" class="btn btn-info" type="submit" value="Submit".>
		<a href="payment.php" class="btn btn-info" role="button">Next.</a>
      </form>
    </div>
  </div>
 
    </div>

</div>
</div>
</body>
</html>
