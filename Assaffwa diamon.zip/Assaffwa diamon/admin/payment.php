<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="stylesheet" href="style_list.css">
</head>
<body>
<div class="topnav">
  <a href="admin_page.php">Home</a>
  <a href="package.php">PACKAGE</a>
  <a href="booking.php">BOOKING</a>
  <a class="active" href="payment.php">PAYMENT</a>
  

  <div class="topnav-right">
    <div id="button"><a href="home.html">Log Out</a>
   
  </div>
</div>
</div>
<p>List PAYMENT.</p>
<?php
include_once('connection.php');
$sql="select pay_id, pay_detail, pay_total, book_id, a_id from payment";
$result= $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table><tr><th>ID</th><th>Detail</th><th>Total</th><th>Booking ID</th><th>Action</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["pay_id"]. "</td><td>" .$row['pay_detail']. " </td><td> " . $row['pay_total']. " </td><td> " . $row["book_id"]. " </td><td> " .$row['a_id']. " </td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}

$conn->close();
?>


</body>
</html>