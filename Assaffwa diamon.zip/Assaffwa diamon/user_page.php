<!DOCTYPE html>
<html>
<head>
<title>|Welcome to Assaffwa Daimon Travel|</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="style_user.css">

</head>
<body>


<div class="topnav">
  <a class="active" href="#home">Home</a>
  <a href="package.php">PACKAGE</a>
  <a href="register.php">REGISTER</a>
  <a href="payment.php">PAYMENT</a>
  <div class=" More ">
    <button class="dropbtn"> More 
    </button>
    <div class="More-content">
      <a href="contact.html">Contact</a>
	  <a href="#">Budget</a> 
      <a href="MUTAWWIF TEAM.html">Mutawwif</a>
	  
	</div>
  </div> 

  <div class="topnav-right">
    <div id="button"><a href="home.html">Log Out</a>
   
  </div>
</div>
</div>

<div class="bg-image"></div>
  
	<div class="bg-text">
	<h2>Welcome to Assaffwa Travel</h2>
	<h1 style="font-size:50px">UMRAH & HAJJI</h1>
	<p>Your Spiritual Journey , Start Here.</p>
	</div>
</div>
</div>

</div>
</body>
</html>
