<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="stylesheet" href="style_book.css">
</head>
<body>
<div class="topnav">
  <a href="admin_page.php">Home</a>
  <a  class="active" href="package.php">PACKAGE</a>
  <a href="booking.php">BOOKING</a>
  <a href="payment.php">PAYMENT</a>
  

  <div class="topnav-right">
    <div id="button"><a href="home.html">Log Out</a>
   
  </div>
</div>
</div>
<p>List PACKAGE.</p>

<?php
include_once('connection.php');
$sql="select pack_id, pack_type, pack_budget, pack_flight, pack_hotel, pack_hotel_madinah, a_id from package";
$result= $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table><tr><th>ID</th><th>Package</th><th>Budget</th><th>Flight</th><th>Hotel Mekkah</th><th>Hotel Madinah</th><th>Action</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["pack_id"]. "</td><td>" .$row['pack_type']. " </td><td> " . $row['pack_budget']. " </td><td> " . $row["pack_flight"]. " </td><td> " .$row['pack_hotel']. " </td><td> " .$row['pack_hotel_madinah']. " </td><td> " .$row['a_id']. "</td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}

$conn->close();
?>

</body>
</html>