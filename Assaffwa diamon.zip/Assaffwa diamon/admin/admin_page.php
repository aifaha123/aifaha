<!DOCTYPE html>
<html>
<head>
<title>|Welcome to Assaffwa Daimon Travel|</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="style_admin.css">

</head>
<body>


<div class="topnav">
  <a class="active" href="Assaffwa-daimon/try.html">Home</a>
  <a href="package.php">PACKAGE</a>
  <a href="booking.php">BOOKING</a>
  <a href="payment.php">PAYMENT</a>
  

  <div class="topnav-right">
    <div id="button"><a href="home.html">Log Out</a>
   
  </div>
</div>
</div>

<div class="bg-image"></div>
  
	<div class="bg-text">
	<h2>Assaffwa Travel</h2>
	<h1 style="font-size:50px">UMRAH & HAJJI</h1>
	<p>Your Spiritual Journey , Start Here.</p>
	</div>
</div>
</div>

</div>
</body>
</html>
