<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="stylesheet" href="style_book.css">
</head>
<body>
<div class="topnav">
  <a href="admin_page.php">Home</a>
  <a href="package.php">PACKAGE</a>
  <a class="active" href="booking">BOOKING</a>
  <a href="payment.php">PAYMENT</a>
  

  <div class="topnav-right">
    <div id="button"><a href="home.html">Log Out</a>
   
  </div>
</div>
</div>
<p>List Booking.</p>
<?php
include_once('connection.php');
$sql="select book_id, book_pack, book_date, book_name, book_num, book_email, book_room from booking";
$result= $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table><tr><th>ID</th><th>Package</th><th>Date</th><th>Name</th><th>Phone Number</th><th>Email</th><th>Room Type</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["book_id"]. "</td><td>" .$row['book_pack']. " </td><td> " . $row['book_date']. " </td><td> " . $row["book_name"]. " </td><td> " .$row['book_num']. " </td><td> " .$row['book_email']. " </td><td> " .$row['book_room']. "</td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}

$conn->close();
?>

</body>
</html>