<?php
include 'config.php';
if (isset($_POST["u_btn"])){
  $u_firstname =$_POST["u_firstname"];
  $u_num =$_POST["u_num"];
  $u_email =$_POST["u_email"];
  $u_pass =$_POST["u_pass"];
  
  if (empty($u_firstname) || empty($u_email)|| empty($u_num)|| empty($u_pass)){
  }else{
	  $insert = mysqli_query($conn,"INSERT INTO `user` (`u_id`, `u_firstname`, `u_num`, `u_email`, `u_pass`) VALUES (NULL, ' $u_firstname', '$u_num', '$u_email', '$u_pass');");
	  echo "succes";
  }
}
 
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="style_su.css">
    <link href="https://fonts.googleapis.com/css?family=Permanent+Marker" rel="stylesheet">
  </head>
  <body>
    <div class="signup-form">

      <form class="" action="sign up.php" method="post">
        <h1>Sign Up</h1>
        <input type="text" name="u_firstname" placeholder="Full Name" class="txtb">
		<input type="text" name="u_num" placeholder="Phone Number" class="txtb">
		<input type="email" name="u_email" placeholder="Email" class="txtb">
        <input type="password" name="u_pass" placeholder="Password" class="txtb">
        <input type="submit" name="u_btn" value="Submit" class="signup-btn">
		<a href="user_page.php">Create Account </a>
        <a href="sign in.php">Already Have one ?</a>
      </form>
   </div>
  </body>
</html>

