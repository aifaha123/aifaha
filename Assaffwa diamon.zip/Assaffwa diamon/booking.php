<?php
include 'config.php';
if (isset($_POST["book_btn"])){
  $book_pack =$_POST["book_pack"];
  $book_date =$_POST["book_date"];
  $book_name =$_POST["book_name"];
  $book_num =$_POST["book_num"];
  $book_email =$_POST["book_email"];
  $book_room =$_POST["book_room"];
 
  
  if (empty($book_pack) || empty($book_date)|| empty($book_name)||  empty($book_num)|| empty($book_email)|| empty($book_room)){
  }else{
	  $insert = mysqli_query($conn,"INSERT INTO `booking` (`book_pack`, `book_date`, `book_name`, `book_num`, `book_email`, `book_room`) VALUES ('$book_pack', '$book_date', '$book_name', '$book_num', '$book_email', '$book_room');");
	  echo "succes";
  }
}
 
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="style_regist.css">
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
</head>
<body>
<div class="topnav">
  <a class="active" href="user_page.php">Home</a>
  <a href="package.html">PACKAGE</a>
  <a href="register.php">REGISTER</a>
  <a href="payment.php">PAYMENT</a>
  <div class=" More ">
    <button class="dropbtn"> More 
    </button>
    <div class="More-content">
      <a href="contact.html">Contact</a>
	  <a href="#">Budget</a> 
      <a href="MUTAWWIF TEAM.html">Mutawwif</a>
	  
	</div>
  </div> 
  </div>
  
<h3>Please Fill in Your Personal Information</h3>
<div class="container">
<form action="booking.php" method="post">
    <label for="name">Your Package </label>
   <select class="form-control" id="book_pack" name="book_pack">
        <option>BRONZE</option>
        <option>PLATINUIM</option>
        <option>GOLD</option>
      </select>
	
	<label for="name">Your Date </label>
   <select class="form-control" id="book_date" name="book_date">
        <option>September 2020</option>
        <option>Oktober 2020</option>
        <option>November 2020</option>
      </select>
	
    <label for="name">Your Name</label>
    <input type="text" id="fname" name="book_name" placeholder="Your name.."><br />

    <label for="num">Phone Number</label>
    <input type="text" id="num" name="book_num" placeholder="Your Phone Number.."><br />
	
	<label for="email">Email</label>
    <input type="email" id="email" name="book_email" placeholder="Your Email.."><br />

	<label for="room">Choose you Type of room(2, 3, 4)</label>
    <select class="form-control" id="book_room" name="book_room">
        <option>Room 2 - RM 7200</option>
        <option>Room 3 - RM 6800</option>
        <option>Room 4 - RM 6500</option>
      </select>


    <input type="submit" name="book_btn" value="Submit">
	
	 <a href="payment.php" class="btn btn-info" role="button">Next.</a>
  </form>
   </div>

</body>
</html>