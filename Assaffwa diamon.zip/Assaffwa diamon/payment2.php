
<!DOCTYPE HTML>
<html class="supernova"><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="alternate" type="application/json+oembed" href="https://www.jotform.com/oembed/?format=json&amp;url=https%3A%2F%2Fform.jotform.com%2F201922577164457" title="oEmbed Form">
<link rel="alternate" type="text/xml+oembed" href="https://www.jotform.com/oembed/?format=xml&amp;url=https%3A%2F%2Fform.jotform.com%2F201922577164457" title="oEmbed Form">
<meta property="og:title" content="PayPal Payment Form" >
<meta property="og:url" content="https://form.jotform.com/201922577164457" >
<meta property="og:description" content="Please click the link to complete this form.">
<meta name="slack-app-id" content="AHNMASS8M">
<link rel="shortcut icon" href="https://cdn.jotfor.ms/favicon.ico">
<link rel="canonical" href="https://form.jotform.com/201922577164457" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=1" />
<meta name="HandheldFriendly" content="true" />
<title>PayPal Payment Form</title>
<link href="https://cdn.jotfor.ms/static/formCss.css?3.3.19032" rel="stylesheet" type="text/css" />
<link type="text/css" media="print" rel="stylesheet" href="https://cdn.jotfor.ms/css/printForm.css?3.3.19032" />
<link type="text/css" rel="stylesheet" href="https://cdn.jotfor.ms/css/styles/nova.css?3.3.19032" />
<link type="text/css" rel="stylesheet" href="https://cdn.jotfor.ms/themes/CSS/566a91c2977cdfcd478b4567.css?themeRevisionID=59fb4852cf3bfe589c6c6f21"/>
<link type="text/css" rel="stylesheet" href="https://cdn.jotfor.ms/css/styles/payment/payment_feature.css?3.3.19032" />
<style type="text/css">
    .form-label-left{
        width:150px;
    }
    .form-line{
        padding-top:12px;
        padding-bottom:12px;
    }
    .form-label-right{
        width:150px;
    }
    body, html{
        margin:0;
        padding:0;
        background:#fff;
    }

    .form-all{
        margin:0px auto;
        padding-top:0px;
        width:590px;
        color:#555 !important;
        font-family:"Lucida Grande", "Lucida Sans Unicode", "Lucida Sans", Verdana, sans-serif;
        font-size:14px;
    }
    .form-radio-item label, .form-checkbox-item label, .form-grading-label, .form-header{
        color: false;
    }

</style>

<style type="text/css" id="form-designer-style">
    /* Injected CSS Code */
/*PREFERENCES STYLE*/
    .form-all {
      font-family: Lucida Grande, sans-serif;
    }
    .form-all .qq-upload-button,
    .form-all .form-submit-button,
    .form-all .form-submit-reset,
    .form-all .form-submit-print {
      font-family: Lucida Grande, sans-serif;
    }
    .form-all .form-pagebreak-back-container,
    .form-all .form-pagebreak-next-container {
      font-family: Lucida Grande, sans-serif;
    }
    .form-header-group {
      font-family: Lucida Grande, sans-serif;
    }
    .form-label {
      font-family: Lucida Grande, sans-serif;
    }
  
    .form-label.form-label-auto {
      
    display: inline-block;
    float: left;
    text-align: left;
  
    }
  
    .form-line {
      margin-top: 12px 36px 12px 36px px;
      margin-bottom: 12px 36px 12px 36px px;
    }
  
    .form-all {
      width: 590px;
    }
  
    .form-label-left,
    .form-label-right,
    .form-label-left.form-label-auto,
    .form-label-right.form-label-auto {
      width: 150px;
    }
  
    .form-all {
      font-size: 14px
    }
    .form-all .qq-upload-button,
    .form-all .qq-upload-button,
    .form-all .form-submit-button,
    .form-all .form-submit-reset,
    .form-all .form-submit-print {
      font-size: 14px
    }
    .form-all .form-pagebreak-back-container,
    .form-all .form-pagebreak-next-container {
      font-size: 14px
    }
  
    .supernova .form-all, .form-all {
      background-color: #fff;
      border: 1px solid transparent;
    }
  
    .form-all {
      color: #555;
    }
    .form-header-group .form-header {
      color: #555;
    }
    .form-header-group .form-subHeader {
      color: #555;
    }
    .form-label-top,
    .form-label-left,
    .form-label-right,
    .form-html,
    .form-checkbox-item label,
    .form-radio-item label {
      color: #555;
    }
    .form-sub-label {
      color: #6f6f6f;
    }
  
    .supernova {
      background-color: undefined;
    }
    .supernova body {
      background: transparent;
    }
  
    .form-textbox,
    .form-textarea,
    .form-radio-other-input,
    .form-checkbox-other-input,
    .form-captcha input,
    .form-spinner input {
      background-color: undefined;
    }
  
    .supernova {
      background-image: none;
    }
    #stage {
      background-image: none;
    }
  
    .form-all {
      background-image: none;
    }
  
  .ie-8 .form-all:before { display: none; }
  .ie-8 {
    margin-top: auto;
    margin-top: initial;
  }
  
  /*PREFERENCES STYLE*//*__INSPECT_SEPERATOR__*/
    /* Injected CSS Code */
</style>

<script src="https://cdnjs.cloudflare.com/ajax/libs/punycode/1.4.1/punycode.min.js"></script>
<script src="https://cdn.jotfor.ms/static/prototype.forms.js" type="text/javascript"></script>
<script src="https://cdn.jotfor.ms/static/jotform.forms.js?3.3.19032" type="text/javascript"></script>
<script src="https://cdn.jotfor.ms/js/payments/paypalcomplete.js?v=3.3.19032" type="text/javascript"></script>
<script src="https://cdn.jotfor.ms/js/payments/paymentUtils.js?v=3.3.19032" type="text/javascript"></script>
<script src="https://cdn.jotfor.ms/js/libraries/promise-polyfill.js"></script>
<script src="https://cdn.jotfor.ms/js/payments/payment_form_embedded.js?v=3.3.19032" type="text/javascript"></script>
<script type="text/javascript">
	JotForm.init(function(){
      productID = {"0":"input_7_1001","1":"input_7_1002","2":"input_7_1003","3":"input_7_1004"};
      paymentType = "product";
      JotForm.setCurrencyFormat('USD',true, 'point');
      JotForm.totalCounter({"input_7_1002":{"price":"6500"},"input_7_1003":{"price":"6900"},"input_7_1004":{"price":"7200"}});
      $$('.form-product-custom_quantity').each(function(el, i){el.observe('blur', function(){isNaN(this.value) || this.value < 1 ? this.value = '0' : this.value = parseInt(this.value)})});
      $$('.form-product-custom_quantity').each(function(el, i){el.observe('focus', function(){this.value == 0 ? this.value = '' : this.value})});
      JotForm.handleProductLightbox();
      setTimeout(function() {
          $('input_5').hint('ex: myname@example.com');
       }, 20);
	JotForm.newDefaultTheme = false;
	JotForm.newPaymentUIForNewCreatedForms = false;
      JotForm.alterTexts(undefined, true);
    /*INIT-END*/
	});

   JotForm.prepareCalculationsOnTheFly([null,{"name":"clickTo","qid":"1","text":"PayPal Payment Form","type":"control_head"},{"name":"submit","qid":"2","text":"Go to Payment Page","type":"control_button"},null,{"name":"yourName","qid":"4","text":"Your Name","type":"control_fullname"},{"name":"yourEmail","qid":"5","text":"Your E-mail","type":"control_email"},{"name":"yourAddress","qid":"6","text":"Your Address","type":"control_address"},{"name":"myProducts","qid":"7","text":"My Products","type":"control_paypalcomplete"},{"name":"paymentMethods","qid":"8","text":"Payment Methods","type":"control_paymentmethods"}]);
   setTimeout(function() {
JotForm.paymentExtrasOnTheFly([null,{"name":"clickTo","qid":"1","text":"PayPal Payment Form","type":"control_head"},{"name":"submit","qid":"2","text":"Go to Payment Page","type":"control_button"},null,{"name":"yourName","qid":"4","text":"Your Name","type":"control_fullname"},{"name":"yourEmail","qid":"5","text":"Your E-mail","type":"control_email"},{"name":"yourAddress","qid":"6","text":"Your Address","type":"control_address"},{"name":"myProducts","qid":"7","text":"My Products","type":"control_paypalcomplete"},{"name":"paymentMethods","qid":"8","text":"Payment Methods","type":"control_paymentmethods"}]);}, 20); 
</script>
</head>
<body>
<form class="jotform-form" action="https://submit.jotform.com/submit/201922577164457/" method="post" name="form_201922577164457" id="201922577164457" accept-charset="utf-8" autocomplete="on">
  <input type="hidden" name="formID" value="201922577164457" />
  <input type="hidden" id="JWTContainer" value="" />
  <input type="hidden" id="cardinalOrderNumber" value="" />
  <div role="main" class="form-all">
    <ul class="form-section page-section">
      <li id="cid_1" class="form-input-wide" data-type="control_head">
        <div class="form-header-group  header-large">
          <div class="header-text httal htvam">
            <h1 id="header_1" class="form-header" data-component="header">
              PayPal Payment 
            </h1>
            <div id="subHeader_1" class="form-subHeader">
              Your Payment
            </div>
          </div>
        </div>
      </li>
      <li class="form-line" data-type="control_paypalcomplete" id="id_7" data-payment="true">
        <label class="form-label form-label-left form-label-auto" id="label_7" for="input_7"> My Package </label>
        <div id="cid_7" class="form-input">
          <div data-wrapper-react="true">
            <div data-wrapper-react="true">
              <div class="filter-container">
              </div>
              <input type="hidden" name="simple_fpc" data-payment_type="paypalcomplete" data-component="payment1" value="7" />
              <input type="hidden" name="payment_total_checksum" id="payment_total_checksum" data-component="payment2" />
              <div id="image-overlay" class="overlay-content" style="display:none">
                <img id="current-image" />
                <span class="lb-prev-button">
                  prev
                </span>
                <span class="lb-next-button">
                  next
                </span>
                <span class="lb-close-button">
                  ( X )
                </span>
                <span class="image-overlay-product-container">
                  <ul class="form-overlay-item" hasicon="false" hasimages="false" iconvalue="">
                  </ul>
                  <ul class="form-overlay-item" hasicon="false" hasimages="false" iconvalue="">
                  </ul>
                  <ul class="form-overlay-item" hasicon="false" hasimages="false" iconvalue="">
                  </ul>
                  <ul class="form-overlay-item" hasicon="false" hasimages="false" iconvalue="">
                  </ul>
                </span>
              </div>
              <div data-wrapper-react="true">
                <span class="form-product-item hover-product-item" categories="non-categorized" pid="1002" style="display:block">
                  <div data-wrapper-react="true" class="form-product-item-detail">
                    <input type="checkbox" class="form-checkbox  form-product-input" id="input_7_1002" name="q7_myProducts[][id]" value="1002" />
                    <label for="input_7_1002" class="form-product-container">
                      <span data-wrapper-react="true">
                        <span class="form-product-name" id="product-name-input_7_1002">
                          Room 4
                        </span>
                        <span class="form-product-details">
                          <b>
                            <span data-wrapper-react="true">
                              RM
                              <span id="input_7_1002_price">
                                6500 
                              </span>
                            </span>
                          </b>
                        </span>
                      </span>
                    </label>
                  </div>
                </span>
                <br/>
                <span class="form-product-item hover-product-item" categories="non-categorized" pid="1003" style="display:block">
                  <div data-wrapper-react="true" class="form-product-item-detail">
                    <input type="checkbox" class="form-checkbox  form-product-input" id="input_7_1003" name="q7_myProducts[][id]" value="1003" />
                    <label for="input_7_1003" class="form-product-container">
                      <span data-wrapper-react="true">
                        <span class="form-product-name" id="product-name-input_7_1003">
                          Room 3
                        </span>
                        <span class="form-product-details">
                          <b>
                            <span data-wrapper-react="true">
                              RM
                              <span id="input_7_1003_price">
                                6900 
                              </span>
                            </span>
                          </b>
                        </span>
                      </span>
                    </label>
                  </div>
                </span>
                <br/>
                <span class="form-product-item hover-product-item" categories="non-categorized" pid="1004" style="display:block">
                  <div data-wrapper-react="true" class="form-product-item-detail">
                    <input type="checkbox" class="form-checkbox  form-product-input" id="input_7_1004" name="q7_myProducts[][id]" value="7200" />
                    <label for="input_7_1004" class="form-product-container">
                      <span data-wrapper-react="true">
                        <span class="form-product-name" id="product-name-input_7_1004">
                          Room 2
                        </span>
                        <span class="form-product-details">
                          <b>
                            <span data-wrapper-react="true">
                              RM
                              <span id="input_7_1004_price">
                                7200 
                              </span>
                            </span>
                          </b>
                        </span>
                      </span>
                      <div class="form-product-description" id="product-name-description-input_7_1004">
                      </div>
                    </label>
                  </div>
                </span>
                <br/>
                <span class="form-payment-total">
                  <b>
                    <span id="total-text">
                      Total
                    </span>
                     
                    <span class="form-payment-price">
                      <span data-wrapper-react="true">
                        RM
                        <span id="payment_total">
                          0.00 
                        </span>
                      </span>
                    </span>
                  </b>
                </span>
              </div>
            </div>
          </div>
        </div>
      </li>
      
      <li class="form-line" data-type="control_paymentmethods" id="id_8">
        <label class="form-label form-label-left" id="label_8" for="input_8"> Payment Methods </label>
        <div id="cid_8" class="form-input">
          <div class="payment-methods-area">
            <div data-wrapper-react="true" class="paypalcomplete-payment-wrapper" data-sandbox="enabled" data-currency="USD" data-billing-address="6" data-auth-only="No" data-show-spb="true" data-show-card-fields="true">
              <div id="paypal-commerce-platform-container">
                <div class="paypal-toggle-buttons">
                  <div class="paypal-toggle">
                    <div id="paypal-card-fields">
                      <div class="payment-method-container" data-id="paypal-card-fields">
                        <input type="radio" name="paypal-payment-method" data-id="paypal-card-fields" id="paypal-card-fields-input" />
                        <label for="paypal-card-fields-input">
                          <span class="CC_ico">
                          </span>
                          Debit or Credit Card
                        </label>
                      </div>
                    </div>
                    <div id="paypal-smart-buttons">
                      <div class="payment-method-container" data-id="paypal-smart-buttons">
                        <input type="radio" name="paypal-payment-method" data-id="paypal-smart-buttons" id="paypal-smart-buttons-input" />
                        <label for="paypal-smart-buttons-input">  </label>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="paypal-toggle-content " render-paypal-type="">
                  <div class="content-area">
                    <div id="paypal-credit-card-fields">
                      <div class="paypal-commerce-platform">
                        <div class="paypal-content">
                          <table class="form-address-table payment-form-table" style="border:0" cellPadding="0" cellSpacing="0">
                            <tbody>
                              <tr>
                                <td width="50%">
                                  <span class="form-sub-label-container " style="vertical-align:top">
                                    <input type="text" id="7_cc_firstName" name="q7_myProducts[cc_firstName]" class="form-textbox cc_firstName" size="20" value="" data-component="cc_firstName" />
                                    <label class="form-sub-label" for="7_cc_firstName" id="sublabel_cc_firstName" style="min-height:13px;margin:0 0 3px 0" aria-hidden="false"> First Name </label>
                                  </span>
                                </td>
                                <td width="50%">
                                  <span class="form-sub-label-container " style="vertical-align:top">
                                    <input type="text" id="7_cc_lastName" name="q7_myProducts[cc_lastName]" class="form-textbox cc_lastName" size="20" value="" data-component="cc_lastName" />
                                    <label class="form-sub-label" for="7_cc_lastName" id="sublabel_cc_lastName" style="min-height:13px;margin:0 0 3px 0" aria-hidden="false"> Last Name </label>
                                  </span>
                                </td>
                              </tr>
                              <tr>
                                <td width="50%">
                                  <span class="form-sub-label-container " style="vertical-align:top">
                                    <div class="form-textbox cc_numberMount cc_number">
                                    </div>
                                    <label class="form-sub-label" for="7_cc_number" id="sublabel_cc_number" style="min-height:13px;margin:0 0 3px 0" aria-hidden="false"> Credit Card Number </label>
                                  </span>
                                </td>
                                <td width="50%">
                                  <span class="form-sub-label-container " style="vertical-align:top">
                                    <div class="form-textbox cc_ccvMount cc_ccv">
                                    </div>
                                    <label class="form-sub-label" for="7_cc_ccv" id="sublabel_cc_ccv" style="min-height:13px;margin:0 0 3px 0" aria-hidden="false"> Security Code </label>
                                  </span>
                                </td>
                              </tr>
                              <tr>
                                <td width="50%">
                                  <span class="form-sub-label-container " style="vertical-align:top">
                                    <div class="form-textbox cc_cardExpiryMount cc_card_expiry">
                                    </div>
                                    <label class="form-sub-label" for="7_cc_card_expiry" id="sublabel_cc_card_expiry" style="min-height:13px;margin:0 0 3px 0" aria-hidden="false"> Card Expiration </label>
                                  </span>
                                </td>
                                <td width="50%">
                                  <tr style="display:none">
                                    <td>
                                      <input id="paypal_complete_dummy" style="display:none" />
                                    </td>
                                  </tr>
                                </td>
                              </tr>
                              <div id="payments-sdk__contingency-lightbox">
                              </div>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                    <div id="paypal-spb-area">
                      <p>Please click one of the PayPal options to complete payment and <b>submit</b> the form.</p>
                      <div id="paypal-button-container" style="pointer-events:">
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <input type="hidden" id="input_8_payment_method" name="q8_paymentMethods[payment_method]" class="" value="" data-component="payment_method" />
          </div>
        </div>
      </li>
      <li class="form-line" data-type="control_button" id="id_2">
        <div id="cid_2" class="form-input-wide">
          <div style="margin-left:156px" data-align="auto" class="form-buttons-wrapper form-buttons-auto   jsTest-button-wrapperField">
            <button id="input_2" type="submit" class="form-submit-button submit-button jf-form-buttons jsTest-submitField" data-component="button" data-content="">
              Go to Payment Page
            </button>
          </div>
        </div>
      </li>
      <li style="display:none">
        Should be Empty:
        <input type="text" name="website" value="" />
      </li>
    </ul>
  </div>
  <script>
  JotForm.showJotFormPowered = "new_footer";
  </script>
  <script>
  JotForm.poweredByText = "Powered by JotForm";
  </script>
  <input type="hidden" id="simple_spc" name="simple_spc" value="201922577164457" />
  <script type="text/javascript">
  document.getElementById("si" + "mple" + "_spc").value = "201922577164457-201922577164457";
  </script>
 
    
  </div>
</form></body>
</html>
