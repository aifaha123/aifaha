<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>PACKAGE</title>
  <link rel="stylesheet" href="Package.css">
  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="topnav">
  <a class="active" href="user_page.php">Home</a>
  <a href="package.html">PACKAGE</a>
  <a href="register.php">REGISTER</a>
  <a href="payment.php">PAYMENT</a>
  <div class=" More ">
    <button class="dropbtn"> More 
    </button>
    <div class="More-content">
      <a href="contact.html">Contact</a>
	  <a href="#">Budget</a> 
      <a href="MUTAWWIF TEAM.html">Mutawwif</a>
	  
	</div>
  </div> 
  </div>
  <div class="pricing-table">
    <div class="pricing-card">
      <h3 class="pricing-card-header">BRONZE</h3>
      <div class="price"><sup>RM</sup>6,850<span>.</span></div>
      <ul>
	
        
        <li><strong>Malaysia Airlines</strong></li>
        <li><strong>MEKKAH:</strong> Hilton Double Tree Jabal Omar</li>
        <li><strong>MADINAH:</strong> Mawadah Al Waha</li>
        
      </ul>
      <a href="bronze.php" class="order-btn">More</a>
    </div>

    <div class="pricing-card">
      <h3 class="pricing-card-header">PLATINIUM</h3>
      <div class="price"><sup>RM</sup>10,500<span>.</span></div>
      <ul>
        
        <li><strong>Saudi Airlines</strong></li>
        <li><strong>MEKKAH:</strong> Hilton Double Tree Jabal Omar</li>
        <li><strong>MADINAH:</strong> Mawadah Al Waha</li>
        
      </ul>
      <a href="platinium.php" class="order-btn">More</a>
    </div>

    <div class="pricing-card">
      <h3 class="pricing-card-header">GOLD</h3>
      <div class="price"><sup>RM</sup>18,850<span>.</span></div>
      <ul>
        
        <li><strong>Saudi Airlines</strong></li>
        <li><strong>MEKKAH:</strong> Clock Royal Tower - A Fairmont Hotel</li>
        <li><strong>MADINAH:</strong> Pullman Zamzam</li>
        
      </ul>
      <a href="gold.php" class="order-btn">More</a>
    </div>
  </div>
  </div>
</body>
</html>