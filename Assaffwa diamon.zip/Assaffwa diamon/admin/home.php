<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="style_home.css">
 <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">
</head>
<body>
<div class="topnav">
  <a class="active" href="#home">Home</a>
  <a href="#news">About Us</a>
  <a href="#">Our Services</a>
  <div class="topnav-right">
    <div id="button"><a href="sign in.html">Login</a>
    <a href="admin.php">Admin</a>
  </div>
</div>
</div>

 <div class="about-section">
        <div class="inner-container">
            <h1>About Us</h1>
            <p class="text">
                Assaffwa Daimon Travels Sdn. Bhd. is a registered & licensed umbrella agency & has been operating since 2018. We are a muassasah-based Umrah agency, which allows us to manage our own Umrah visas without going through a third party. We also have offices in Mecca & Medina to ensure that every congregation's affairs & welfare are taken care of. 
				Your Spiritual Journey, STARTS HERE.
             </p>
            <div class="skills">
                <span>FIND THE BEST DATE</span>
                <span>FINDE THE BEST PACKAGES</span>
                <span>AND BOOK YOUR UMRAH</span>
            </div>
        </div>
    </div>
<div class="services-section">
      <div class="inner-width">
        <h1 class="section-title">Our Services</h1>
        <div class="border"></div>
        <div class="services-container">

          <div class="service-box">
            <div class="service-icon">
              <i class="fas fa-plane-departure"></i>
            </div>
            <div class="service-title">Flight</div>
            <div class="service-desc">
              We chose direct flights from KLIA to the Holy Land as our main flight. In addition, we also provide transit flights for those in need..
            </div>
          </div>

          <div class="service-box">
            <div class="service-icon">
              <i class="fas fa-bus"></i>
            </div>
            <div class="service-title">Comfortable Transportation</div>
            <div class="service-desc">
              Bus, coaster or car service is in the best and best condition for travelers to experience a more comfortable and safe travel experience.
            </div>
          </div>

          <div class="service-box">
            <div class="service-icon">
              <i class="fas fa-hotel"></i>
            </div>
            <div class="service-title">Comfortable accommodation</div>
            <div class="service-desc">
              Accommodation is provided in accordance with the registered package. We strive to ensure that our guests have a comfortable, quality and secure hotel.
            </div>
          </div>

          <div class="service-box">
            <div class="service-icon">
              <i class="far fa-user"></i>
            </div>
            <div class="service-title">Quality Mutawif</div>
            <div class="service-desc">
              Each group will be led by an experienced Mutawif who is responsible for the welfare and providing knowledge, guidance and guidance to the congregation.
            </div>
          </div>
			<div class="service-box">
            <div class="service-icon">
              <i class="fas fa-id-card-alt"></i>
            </div>
            <div class="service-title">Medical Card</div>
            <div class="service-desc">
              In the event of an accident or health problem, your medical bill will be covered & managed (Up to SAR10,000)
            </div>
          </div>

          <div class="service-box">
            <div class="service-icon">
              <i class="fas fa-chalkboard-teacher"></i>
            </div>
            <div class="service-title">Umrah Course</div>
            <div class="service-desc">
              A free weekly umrah course with Assaffwa Daimon Travels publication guide.
            </div>
          </div>

          <div class="service-box">
            <div class="service-icon">
              <i class="fas fa-atlas"></i>
            </div>
            <div class="service-title">VISA Management</div>
            <div class="service-desc">
              We will assist you in handling visa related matters. * Excludes visa fee by the Saudi government.
            </div>
          </div>
		  
		   <div class="service-box">
            <div class="service-icon">
              <i class="fa fa-gift"></i>
            </div>
            <div class="service-title">Special Gift</div>
            <div class="service-desc">
              You will get Special Luggage Set, 5L Zam Zam water & Telephone Mini for the congregation & Ihram Cloth for the congregation.
            </div>
          </div>
        </div>
      </div>
    </div>
 <div class="main">

<h1 class="section-title">PACKAGE</h1>
  <div class="border"></div>

<h2 class="section-title"> OUR PROMOTION</h2>
<p class="section-title">
Special for all of you with an exciting package and you can experience the experience of performing umrah with us.
</p>

<!-- Portfolio Gallery Grid -->
<div class="row">
  <div class="column">
    <div class="content">
      <img src="promo.jpg" alt="Mountains" style="width:100%">
      <div class="service-title">HAJI FURADA</div>
     
    </div>
  </div>
  <div class="column">
    <div class="content">
    <img src="promo2.jpg" alt="Lights" style="width:100%">
      <div class="service-title">UMRAH PROMO</div>
     
    </div>
  </div>
  <div class="column">
    <div class="content">
    <img src="promo3.jpg" alt="Nature" style="width:100%">
      <div class="service-title">UMRAH RAMADHAN</div>
      
    </div>
  </div>
  <div class="column">
    <div class="content">
    <img src="promo4.jpg" alt="Mountains" style="width:100%">
      <div class="service-title">UMRAH</div>
      
    </div>
  </div>
</div>
</div>
</body>
</html>
