<?php
include 'config.php';
if (isset($_POST["u_btn"])){
  $u_email =$_POST["u_email"];
  $u_pass =$_POST["u_pass"];
   if ( empty($u_email)|| empty($u_pass)){
	   echo"Please Complet All Data";
   }else{ 
   $selectfdb = mysqli_query($conn,"SELECT * FROM user WHERE u_email = '$u_email' AND u_pass = '$u_pass' ");
   $row = mysqli_fetch_array($selectfdb);
    if($row["u_email"] == $u_email && $row["u_pass"] == $u_pass){
		echo "Welcome ".$row["u_firstname"]." in Your Account";
	}else{
		 echo"Email or Password Incorrect";
	} 
  }
}
 
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Sign In</title>
    <link rel="stylesheet" href="style_si.css">
    <link href="https://fonts.googleapis.com/css?family=Permanent+Marker" rel="stylesheet">
  </head>
  <body>
    <div class="signin-form">
      <form class="" action="user_page.php" method="post">
        <h1>Sign In</h1>
        <input type="email" name="u_email" placeholder="Email" class="txtb">
        <input type="password" name="u_pass" placeholder="Password" class="txtb">
        <input type="submit" value="Sign In" name="u_btn" class="signin-btn">
        <a href="sign up.php">Sign Up</a>
      </form>
     </div>
  </body>
</html>
