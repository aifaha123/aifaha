<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">
  <link rel="stylesheet" href="style_bpg.css">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
</head>
<body>
<a href="bronze.php" class="previous">&laquo; Previous</a>
<a href="platinium.php" class="next">Next &raquo;</a>

<h2>Pakej Umrah September 2020</h2>
<p>Umrah September (BRONZE):Jeddah → Madinah → Mekah</p>

<div class="row">
  <div class="column">
    <div class="card">
      <h5 class="col-12 col-md-6 col-lg-5 col-xl-5 u-title u-font-size--base u-normal">
		 <span class="c-long-card__icon-plane">✈️</span>
		 <span class="c-long-card__depart">Thu 24 Sep 2020</span>
		 <span class="c-long-card__icon-arrow">→</span>
		 <span class="c-long-card__arrival">Mon 05 Oct 2020</span>
	 </h5>
      <h4>From RM 6850</h4>
      <button class="btn success">Available</button>
	  
	  <div>
	  <a href="booking.php" class="btn warning">Book Now</a>
	  </div>
	  
    </div>
  </div>

  <div class="column">
    <div class="card">
      <h5 class="col-12 col-md-6 col-lg-5 col-xl-5 u-title u-font-size--base u-normal">
		 <span class="c-long-card__icon-plane">✈️</span>
		 <span class="c-long-card__depart">Thu 24 Sep 2020</span>
		 <span class="c-long-card__icon-arrow">→</span>
		 <span class="c-long-card__arrival">Mon 05 Oct 2020</span>
	 </h5>
      <h4>From RM 6850</h4>
      <button class="btn success">Available</button>
      <div>
	  <a href="booking.php" class="btn warning">Book Now</a>
	  </div>
    </div>
  </div>
  
  <div class="column">
    <div class="card">
      <h5 class="col-12 col-md-6 col-lg-5 col-xl-5 u-title u-font-size--base u-normal">
		 <span class="c-long-card__icon-plane">✈️</span>
		 <span class="c-long-card__depart">Thu 24 Sep 2020</span>
		 <span class="c-long-card__icon-arrow">→</span>
		 <span class="c-long-card__arrival">Mon 05 Oct 2020</span>
	 </h5>
      <h4>From RM 6850</h4>
      <button class="btn success">Available</button>
      <div>
      <div>
	  <a href="booking.php" class="btn warning">Book Now</a>
	  </div>
	  </div>
    </div>
  </div>
  
  <div class="column">
    <div class="card">
      <h5 class="col-12 col-md-6 col-lg-5 col-xl-5 u-title u-font-size--base u-normal">
		 <span class="c-long-card__icon-plane">✈️</span>
		 <span class="c-long-card__depart">Thu 24 Sep 2020</span>
		 <span class="c-long-card__icon-arrow">→</span>
		 <span class="c-long-card__arrival">Mon 05 Oct 2020</span>
	 </h5>
       <h4>From RM 6850</h4>
      <button class="btn success">Available</button>
      <div>
    <div>
	  <a href="booking.php" class="btn warning">Book Now</a>
	  </div>
	  </div>
    </div>
  </div>
</div>
</div>
<h2>Pakej Umrah  Oktober  2020</h2>
<p>Umrah  Oktober  (BRONZE): Jeddah → Madinah → Mekah</p>

<div class="row">
  <div class="column">
    <div class="card">
      <h5 class="col-12 col-md-6 col-lg-5 col-xl-5 u-title u-font-size--base u-normal">
		 <span class="c-long-card__icon-plane">✈️</span>
		 <span class="c-long-card__depart">Thu 24 Oct 2020</span>
		 <span class="c-long-card__icon-arrow">→</span>
		 <span class="c-long-card__arrival">Mon 05 Oct 2020</span>
	 </h5>
      <h4>From RM 6850</h4>
      <button class="btn success">Available</button>
	  
	  <div>
	 <div>
	  <a href="booking.php" class="btn warning">Book Now</a>
	  </div>
	  </div>
	  
    </div>
  </div>

  <div class="column">
    <div class="card">
      <h5 class="col-12 col-md-6 col-lg-5 col-xl-5 u-title u-font-size--base u-normal">
		 <span class="c-long-card__icon-plane">✈️</span>
		 <span class="c-long-card__depart">Thu 24 Oct 2020</span>
		 <span class="c-long-card__icon-arrow">→</span>
		 <span class="c-long-card__arrival">Mon 05 Oct 2020</span>
	 </h5>
      <h4>From RM 6850</h4>
      <button class="btn success">Available</button>
      <div>
	  <div>
	  <a href="booking.php" class="btn warning">Book Now</a>
	  </div>
	  </div>
    </div>
  </div>
</div> 
  <h2>Pakej Umrah  November  2020</h2>
<p>Umrah  November  (BRONZE): Jeddah → Madinah → Mekah</p>

<div class="row">
  <div class="column">
    <div class="card">
      <h5 class="col-12 col-md-6 col-lg-5 col-xl-5 u-title u-font-size--base u-normal">
		 <span class="c-long-card__icon-plane">✈️</span>
		 <span class="c-long-card__depart">Thu 24 Nov 2020</span>
		 <span class="c-long-card__icon-arrow">→</span>
		 <span class="c-long-card__arrival">Mon 05 Nov 2020</span>
	 </h5>
      <h4>From RM 6850</h4>
      <button class="btn success">Available</button>
	  
	  <div>
	  <div>
	  <a href="booking.php" class="btn warning">Book Now</a>
	  </div>
	  </div>
	  
    </div>
  </div>

  <div class="column">
    <div class="card">
      <h5 class="col-12 col-md-6 col-lg-5 col-xl-5 u-title u-font-size--base u-normal">
		 <span class="c-long-card__icon-plane">✈️</span>
		 <span class="c-long-card__depart">Thu 24 Nov 2020</span>
		 <span class="c-long-card__icon-arrow">→</span>
		 <span class="c-long-card__arrival">Mon 05 Nov 2020</span>
	 </h5>
      <h4>From RM 6850</h4>
      <button class="btn success">Available</button>
      <div>
	 <div>
	  <a href="booking.php" class="btn warning">Book Now</a>
	  </div>
	  </div>
    </div>
  </div>
  
  <div class="column">
    <div class="card">
      <h5 class="col-12 col-md-6 col-lg-5 col-xl-5 u-title u-font-size--base u-normal">
		 <span class="c-long-card__icon-plane">✈️</span>
		 <span class="c-long-card__depart">Thu 24 Nov 2020</span>
		 <span class="c-long-card__icon-arrow">→</span>
		 <span class="c-long-card__arrival">Mon 05 Nov 2020</span>
	 </h5>
      <h4>From RM 6850</h4>
      <button class="btn success">Available</button>
      <div>
     <div>
	  <a href="booking.php" class="btn warning">Book Now</a>
	  </div>
	  </div>
    </div>
  </div>
</body>
</html>
